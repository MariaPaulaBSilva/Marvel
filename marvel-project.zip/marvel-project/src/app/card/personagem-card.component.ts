import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'personagem',
  standalone: true,
  imports: [ CommonModule ],
  templateUrl: './personagem-card.component.html',
  styleUrls: ['./personagem-card.component.css']
})
export class PersonagemCardComponent {
  @Input() nome!: string; 
  @Input() imagem!: string;
}