import { AuthService } from './auth.service';
export const  AppConfig  = {

  apiBaseUrl: 'http://gateway.marvel.com/v1/public/',
  publicKey: '018a97ff9d03e4f1eda0162a1b1a06e6', 
  privateKey: '451e7dfafd7e3b76c2221013a3a66bdf173f361a', 
  environment: 'development', 
  appName: 'Marvel App', 
  defaultPageSize: 10,
  providers: [AuthService] 
};