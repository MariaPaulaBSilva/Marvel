import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import md5 from 'md5';
import { ApiResponse, Character, Thumbnail } from './marvel-character.model';
import { AppConfig } from './app.config';


@Injectable({
    providedIn: 'root'
})
export class AuthService {

    private loggedIn = false;

    constructor(private http: HttpClient, private router: Router) { }

    login(email: string, password: string): Observable<any> {

        if (email === 'admin@example.com' && password === 'senha123') {
            this.loggedIn = true;
            return this.getPersonagens();
        } else {
            return of({ error: 'Credenciais inválidas!' });
        }
    }
    logout() {
        this.loggedIn = false;
        this.router.navigate(['/login']);
    }

    isAuthenticated(): boolean {
        return this.loggedIn;
    }


    getPersonagens(): Observable<Character[]> {
        const ts = Date.now();
        const hash = this.generateHash(ts);

        const apiUrl = `${AppConfig.apiBaseUrl}characters?ts=${ts}&apikey=${AppConfig.publicKey}&hash=${hash}`;
        return this.http.get<ApiResponse>(apiUrl).pipe(
            map(response => {

                return response.data.results.map((char) => ({
                    id: char.id,
                    name: char.name,
                    description: char.description || '',
                    thumbnail: {
                        path: char.thumbnail.path,
                        extension: char.thumbnail.extension
                    } as Thumbnail
                }));
            }),
            catchError(error => {
                console.error('Erro ao buscar personagens:', error);
                return of([]);
            })
        );
    }

    getCharacterById(id: number): Observable<any> {
        const ts = Date.now();
        const hash = this.generateHash(ts);

        const url = `${AppConfig.apiBaseUrl}/${id}?ts=${ts}&apikey=${AppConfig.publicKey}&hash=${hash}`;

        return this.http.get(url).pipe(
            map((response: any) => {
                const character = response.data.results[0];
                return {
                    id: character.id,
                    name: character.name,
                    thumbnail: `${character.thumbnail.path}/portrait_xlarge.${character.thumbnail.extension}`,
                    comics: character.comics.items
                };
            })
        );
    }
    private generateHash(ts: number): string {
        return md5(ts + AppConfig.privateKey + AppConfig.publicKey);
    }
}