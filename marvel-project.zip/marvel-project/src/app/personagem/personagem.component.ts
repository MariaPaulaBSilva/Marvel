import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'personagem',
  templateUrl: './personagem.component.html',
  styleUrls: ['./personagem.component.css'],
  standalone: true 
})
    
export class PersonagemComponent { }
