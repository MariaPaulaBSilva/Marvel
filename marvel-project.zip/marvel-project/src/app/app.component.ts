import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PersonagemCardComponent } from './card/personagem-card.component';
import { CarrosselComponent } from './carrosel/carrossel.component';
import { LoginComponent } from "./login/login.component";
import { HeaderComponent } from './header/header.component';
import { PersonagemComponent } from './personagem/personagem.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    PersonagemCardComponent,
    CarrosselComponent,
    HeaderComponent,
    LoginComponent,
    PersonagemComponent
],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'marvel-project';
}
