import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PersonagemCardComponent } from '../card/personagem-card.component';
import { AuthService } from '../auth.service';

@Component({
  selector: 'carrossel',
  templateUrl: './carrossel.component.html',
  styleUrls: ['./carrossel.component.css'],
  imports : [
    PersonagemCardComponent
  ],
  standalone: true 
})
export class CarrosselComponent implements OnInit {
  personagens: any[] = [];
  index = 0; 

  constructor(private authService: AuthService) {}

  ngOnInit() {
    this.getPersonagens();
  }
  getPersonagens() {
    this.authService.login('admin@example.com', 'senha123').subscribe(response => {
      if (response && !response.error) {
        this.personagens = response;
      } else {
        console.error(response.error);
      }
    });
  }

  next() {
    if (this.index < this.personagens.length - 1) {
      this.index++;
    } else {
      this.index = 0; 
    }
  }

  prev() {
    if (this.index > 0) {
      this.index--;
    } else {
      this.index = this.personagens.length - 1; 
    }
  }
}