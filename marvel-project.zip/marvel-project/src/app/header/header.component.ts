import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
    standalone: true
})
export class HeaderComponent {
    menuVisible = false; 

    constructor(private router: Router) {}

    goBack(): void {
        this.router.navigate(['..']); 
    }

    toggleMenu(): void {
        this.menuVisible = !this.menuVisible; 
    }

    navigateToCharacters(): void {
        this.router.navigate(['/personagens']); 
        this.menuVisible = false; 
    }

    logout(): void {
        this.router.navigate(['/login']);
        this.menuVisible = false; 
    }
}
